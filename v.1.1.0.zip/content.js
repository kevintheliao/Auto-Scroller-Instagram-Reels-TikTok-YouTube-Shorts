let lastVideo = null;
let autoScrollEnabled = false;
let videoSetupIntervalId = null;
let pendingScrollOnCommentsClose = false;

let commentsOpen = false;
setInterval(() => {
    try {
        const open = areCommentsOpen();
        if (open && !commentsOpen) {
            commentsOpen = true;
        } else if (!open && commentsOpen) {
            commentsOpen = false;
            if (pendingScrollOnCommentsClose) {
                pendingScrollOnCommentsClose = false;
                try { scrollDown(); } catch (e) { }
            }
        }
    } catch (e) {
    }
}, 500);

chrome.runtime.onMessage.addListener(({ enabled }) => {
    autoScrollEnabled = enabled;
    if (enabled) {
        setupVideoEndListener();
        if (!videoSetupIntervalId) {
            videoSetupIntervalId = setInterval(setupVideoEndListener, 300);
        }
    } else {
        if (lastVideo && lastVideo._autoScrollHandler) {
            lastVideo.removeEventListener("ended", lastVideo._autoScrollHandler);
        }
        lastVideo = null;
        if (videoSetupIntervalId) {
            clearInterval(videoSetupIntervalId);
            videoSetupIntervalId = null;
        }
    }
});

chrome.storage.sync.get("enabled", ({ enabled }) => {
    autoScrollEnabled = enabled;
    if (enabled) {
        setupVideoEndListener();
        if (!videoSetupIntervalId) {
            videoSetupIntervalId = setInterval(setupVideoEndListener, 300);
        }
    }
});

function getCurrentVideo() {
    const videos = Array.from(document.querySelectorAll("video"));
    const current = videos.find(v => {
        const r = v.getBoundingClientRect();
        return r.top >= 0 && r.bottom <= window.innerHeight;
    });
    return current || null;
}

function scrollDown() {
    const allVideos = Array.from(document.querySelectorAll("video"));
    const currentVideo = getCurrentVideo();
    if (!currentVideo) return;

    if (areCommentsOpen()) return;

    const currentIndex = allVideos.findIndex(v => v === currentVideo);
    const nextVideo = allVideos[currentIndex + 1];

    if (nextVideo) {
        nextVideo.scrollIntoView({
            behavior: "smooth",
            inline: "center",
            block: "center",
        });
    }
}

function setupVideoEndListener() {
    const video = getCurrentVideo();
    
    if (!video) return;

    if (video === lastVideo) return;

    if (lastVideo) {
        lastVideo.removeEventListener("ended", lastVideo._autoScrollHandler);
    }

    const handler = () => {
        if (areCommentsOpen()) {
            pendingScrollOnCommentsClose = true;
        } else {
            scrollDown();
        }
    };

    video._autoScrollHandler = handler;
    video.addEventListener("ended", handler);

    lastVideo = video;
}

function areCommentsOpen() {
    const dialog = document.querySelector('dialog, [role="dialog"], [aria-modal="true"]');
    if (dialog) {
        const r = dialog.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) return true;
    }

    const textarea = document.querySelector('textarea[placeholder*="Add a comment"], textarea[aria-label*="Add a comment"], textarea[name*="comment"]');
    if (textarea) {
        const r = textarea.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) return true;
    }

    const commentContainers = Array.from(document.querySelectorAll('[data-testid*="comment"], [aria-label*="comments"], [class*="comments"], [id*="comments"]'));
    for (const el of commentContainers) {
        const r = el.getBoundingClientRect();
        if ((el.innerText && el.innerText.trim().length > 0) && r.width > 0 && r.height > 0) return true;
    }

    return false;
}

function isRelevantPage() {
    try {
        const host = location.hostname || '';
        if (!/(^|\.)instagram\.com$/.test(host)) return false;
        const p = (location.pathname || '/').toLowerCase();
        if (p === '/' || p === '') return true; // home
        if (p.startsWith('/reel') || p.startsWith('/reels')) return true; // reels pages
        return false;
    } catch (e) {
        return false;
    }
}

document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        return;
    }

    if (e.key.toLowerCase() === 'r') {
        if (!isRelevantPage()) {
            return;
        }
        autoScrollEnabled = !autoScrollEnabled;
        try {
            chrome.storage.sync.set({ enabled: autoScrollEnabled });
        } catch (err) { }
        try {
            showAutoScrollToast(autoScrollEnabled);
        } catch (e) {}
        if (autoScrollEnabled) {
            setupVideoEndListener();
            if (!videoSetupIntervalId) {
                videoSetupIntervalId = setInterval(setupVideoEndListener, 300);
            }
        } else {
            if (lastVideo && lastVideo._autoScrollHandler) {
                lastVideo.removeEventListener("ended", lastVideo._autoScrollHandler);
            }
            lastVideo = null;
            if (videoSetupIntervalId) {
                clearInterval(videoSetupIntervalId);
                videoSetupIntervalId = null;
            }
        }
    }

    const currentVideo = getCurrentVideo();
    if (!currentVideo) return;

    const allVideos = Array.from(document.querySelectorAll("video"));
    const currentIndex = allVideos.indexOf(currentVideo);
    if (currentIndex === -1) return;

    if (e.key.toLowerCase() === 'c') {
        const allCommentButtons = Array.from(document.querySelectorAll('[aria-label*="Comment"], button[aria-label*="Comment"], [data-testid*="comment"]'));
        const commentButton = allCommentButtons[currentIndex];
        if (commentButton) {
            const event = new MouseEvent('click', { bubbles: true, cancelable: true });
            commentButton.dispatchEvent(event);
        }
    }
    
    if(e.key.toLowerCase() === 'f') {
        const allLikeButtons = Array.from(document.querySelectorAll('[aria-label*="Like"], [aria-label*="Unlike"], button[aria-label*="Like"], button[aria-label*="Unlike"], [data-testid*="like"]'));
        const likeButton = allLikeButtons[currentIndex];
        if (likeButton) {
            const event = new MouseEvent('click', { bubbles: true, cancelable: true });
            likeButton.dispatchEvent(event);
        }
    }
});

let _autoScrollToastTimer = null;
function showAutoScrollToast(enabled) {
    try {
        const id = 'autoscroll-toast-unique-v1';
        let el = document.getElementById(id);
        if (!el) {
            el = document.createElement('div');
            el.id = id;
            el.style.position = 'fixed';
            el.style.left = '200px';
            el.style.bottom = '20px';
            el.style.zIndex = '2147483647';
            el.style.background = '#666';
            el.style.color = '#fff';
            el.style.padding = '8px 12px';
            el.style.borderRadius = '8px';
            el.style.boxShadow = '0 6px 18px rgba(0,0,0,0.2)';
            el.style.fontSize = '14px';
            el.style.fontFamily = 'Arial, Helvetica, sans-serif';
            el.style.opacity = '0';
            el.style.transform = 'translateY(8px)';
            el.style.transition = 'opacity 220ms ease, transform 220ms ease';
            el.style.pointerEvents = 'auto';
            el.style.cursor = 'default';
            document.documentElement.appendChild(el);
        }

        el.textContent = `Auto Scroll: ${enabled ? 'On' : 'Off'}`;

        window.requestAnimationFrame(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        });

        if (_autoScrollToastTimer) {
            clearTimeout(_autoScrollToastTimer);
        }
        _autoScrollToastTimer = setTimeout(() => {
            try {
                el.style.opacity = '0';
                el.style.transform = 'translateY(8px)';
            } catch (e) {}
        }, 1400);
    } catch (e) { }
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.enabled) {
        autoScrollEnabled = !!changes.enabled.newValue;
        try { showAutoScrollToast(autoScrollEnabled); } catch (e) {}
    }
});